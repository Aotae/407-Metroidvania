﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cam_move_test : MonoBehaviour
{
    public float speed = 20;
    private Vector2 motion;
    void FixedUpdate()
    {
        motion = new Vector2(Input.GetAxisRaw("Horizontal"), 0);
        transform.Translate(motion * speed * Time.deltaTime);
    }
}
