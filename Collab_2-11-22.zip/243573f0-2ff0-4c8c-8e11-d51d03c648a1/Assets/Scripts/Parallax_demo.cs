﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax_demo : MonoBehaviour
{
    // Start is called before the first frame update
    private float length, start;
    public GameObject main_cam;
    public float parallaxEffect;
    void Start()
    {
        start = transform.position.x;
        length = GetComponent<SpriteRenderer>().bounds.size.x;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float temp = (main_cam.transform.position.x * (1 - parallaxEffect));
        float dist = (main_cam.transform.position.x * parallaxEffect);
        transform.position = new Vector3(start + dist, transform.position.y, transform.position.z);
        if (temp > start + length)
        {
            start += length;
        }
        else
        {
            if (temp < start - length)
            {
                start -= length;
            }
        }
    }

}
